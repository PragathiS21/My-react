import React from 'react'

function FirstComponent() {
  return (
    <div>
      <div>FirstComponent</div>
      <SecondComponent/>
    </div>
  )
}
function SecondComponent(){
    return(
        <div>SecondComponent()</div>
    )
}
export default FirstComponent
