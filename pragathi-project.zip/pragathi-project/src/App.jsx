import React from 'react'
import FirstComponent from './FirstComponent'
import Fruit from './ClassComponent'
import Arguments from './Arguments'
import PropsChildren from './PropsChildren'
import ClassResult from './ConditionalRendering'
import CarBrand from './Logical'
import ClassResult1 from './TernaryOperator'
import Car1 from './Destructuring'
import Parent1 from './PropDrilling'

function App() {
  return (
    <div>
      <div>App</div>
      <FirstComponent />
      <Fruit />
      <Arguments name="Kavya" phno="8888" />
      <PropsChildren />
      <ClassResult isresult={true} />
       <CarBrand brand='BMW' />
      <ClassResult1 is result={false}/>
      <Car1 brand="Ford" model="Mustang" color="red" year={1969}/>
      <Parent1 studentName="Pragathi"/>
    </div>
  )
}

export default App
