import React from 'react'
import FirstComponent from './FirstComponent'
import Fruit from './ClassComponent'
import Arguments from './Arguments'
import PropsChildren from './PropsChildren'

function App() {
  return (
    <div>
    <div>App</div>
    <FirstComponent></FirstComponent>
    <Fruit/>
    <Arguments name="Kavya" phno="8888"/>
    <PropsChildren/>
    </div>
  )
}

export default App
