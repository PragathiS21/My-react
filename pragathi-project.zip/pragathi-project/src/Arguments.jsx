import React from 'react'

function Arguments(props) {
  return (
    <div>Arguments{props.phno}{props.name}</div>
  )
}
export default Arguments
      
   

