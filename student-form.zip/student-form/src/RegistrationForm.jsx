import React, { useState } from "react";

function RegistrationForm({ onSubmit }) {
  const [form, setForm] = useState({
    fullName: "",
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone: "",
    gender: "",
    dob: "",
    department: "",
    address: "",
  });

  const [errors, setErrors] = useState({});

 
  const validateField = (name, value) => {
    let message = "";

    switch (name) {
      case "fullName":
        if (!value.trim()) message = "Full Name is required.";
        else if (!/^[A-Za-z\s]+$/.test(value))
          message = "Full Name must contain only letters and spaces.";
        break;

      case "username":
        if (value.length < 5) message = "Username must be at least 5 characters.";
        else if (/\s/.test(value)) message = "Username cannot contain spaces.";
        else if (/[^A-Za-z0-9]/.test(value))
          message = "Username must not contain special characters.";
        break;

      case "email":
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value))
          message = "Invalid email format.";
        break;

      case "password":
        if (value.length < 8) message = "Password must be at least 8 characters.";
        else if (!/[A-Z]/.test(value))
          message = "Password must contain an uppercase letter.";
        else if (!/[a-z]/.test(value))
          message = "Password must contain a lowercase letter.";
        else if (!/[0-9]/.test(value))
          message = "Password must contain a number.";
        else if (!/[!@#$%^&*]/.test(value))
          message = "Password must contain a symbol (!@#$%^&*).";
        else if (value === form.username)
          message = "Password cannot be the same as username.";
        break;

      case "confirmPassword":
        if (value !== form.password) message = "Passwords do not match.";
        break;

      case "phone":
        if (!/^\d{10}$/.test(value))
          message = "Phone number must be exactly 10 digits.";
        break;

      case "gender":
        if (!value) message = "Please select your gender.";
        break;

      case "dob":
        if (!value) message = "Please select your date of birth.";
        else if (new Date(value) > new Date())
          message = "Date of birth cannot be in the future.";
        break;

      case "department":
        if (!value) message = "Please select your department.";
        break;

      case "address":
        if (!value.trim()) message = "Address is required.";
        break;

      default:
        break;
    }

    return message;
  };

  
  const handleChange = (e) => {
    const { name, value } = e.target;

    setForm({ ...form, [name]: value });

    const errorMsg = validateField(name, value);
    setErrors({ ...errors, [name]: errorMsg });
  };

  
  const handleSubmit = (e) => {
    e.preventDefault();

    const newErrors = {};
    Object.keys(form).forEach((key) => {
      const errorMsg = validateField(key, form[key]);
      if (errorMsg) newErrors[key] = errorMsg;
    });

    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      onSubmit(form);
    }
  };

  return (
    <form className="registration-form" onSubmit={handleSubmit}>
      <div className="form-grid">
        
        <div className="form-group">
          <label>Full Name</label>
          <input
            type="text"
            name="fullName"
            value={form.fullName}
            onChange={handleChange}
            className={errors.fullName ? "invalid" : ""}
          />
          {errors.fullName && <small>{errors.fullName}</small>}
        </div>

        
        <div className="form-group">
          <label>Username</label>
          <input
            type="text"
            name="username"
            value={form.username}
            onChange={handleChange}
            className={errors.username ? "invalid" : ""}
          />
          {errors.username && <small>{errors.username}</small>}
        </div>

        
        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={form.email}
            onChange={handleChange}
            className={errors.email ? "invalid" : ""}
          />
          {errors.email && <small>{errors.email}</small>}
        </div>

        
        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            name="password"
            value={form.password}
            onChange={handleChange}
            className={errors.password ? "invalid" : ""}
          />
          {errors.password && <small>{errors.password}</small>}
        </div>

        
        <div className="form-group">
          <label>Confirm Password</label>
          <input
            type="password"
            name="confirmPassword"
            value={form.confirmPassword}
            onChange={handleChange}
            className={errors.confirmPassword ? "invalid" : ""}
          />
          {errors.confirmPassword && <small>{errors.confirmPassword}</small>}
        </div>

        
        <div className="form-group">
          <label>Phone Number</label>
          <input
            type="text"
            name="phone"
            value={form.phone}
            onChange={handleChange}
            className={errors.phone ? "invalid" : ""}
          />
          {errors.phone && <small>{errors.phone}</small>}
        </div>

        
        <div className="form-group">
          <label>Gender</label>
          <select
            name="gender"
            value={form.gender}
            onChange={handleChange}
            className={errors.gender ? "invalid" : ""}
          >
            <option value="">Select</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
          {errors.gender && <small>{errors.gender}</small>}
        </div>

        
        <div className="form-group">
          <label>Date of Birth</label>
          <input
            type="date"
            name="dob"
            value={form.dob}
            onChange={handleChange}
            className={errors.dob ? "invalid" : ""}
          />
          {errors.dob && <small>{errors.dob}</small>}
        </div>

        {/* Department */}
        <div className="form-group">
          <label>Department / Course</label>
          <select
            name="department"
            value={form.department}
            onChange={handleChange}
            className={errors.department ? "invalid" : ""}
          >
            <option value="">Select</option>
            <option value="CSE">Computer Science</option>
            <option value="ECE">Electronics</option>
            <option value="ME">Mechanical</option>
            <option value="CE">Civil</option>
            <option value="EEE">Electrical</option>
          </select>
          {errors.department && <small>{errors.department}</small>}
        </div>

        
        <div className="form-group full-width">
          <label>Address</label>
          <textarea
            name="address"
            value={form.address}
            onChange={handleChange}
            className={errors.address ? "invalid" : ""}
            rows="3"
          ></textarea>
          {errors.address && <small>{errors.address}</small>}
        </div>
      </div>

      <button type="submit" className="submit-btn">
        Register
      </button>
    </form>
  );
}

export default RegistrationForm;
