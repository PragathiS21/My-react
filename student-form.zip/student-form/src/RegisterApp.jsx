import React, { useState } from "react";
import RegistrationForm from "./RegistrationForm";
import "./App.css";

function RegisterApp() {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleFormSubmit = (data) => {
    console.log("Student Registered:", data);
    setIsSubmitted(true);
  };

  return (
    <div className="register-app">
      <h1 className="header">🎓 Student Registration Portal</h1>
      {!isSubmitted ? (
        <RegistrationForm onSubmit={handleFormSubmit} />
      ) : (
        <div className="success-message">✅ Registration Successful!</div>
      )}
    </div>
  );
}

export default RegisterApp;
