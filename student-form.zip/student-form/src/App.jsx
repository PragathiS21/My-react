import React from "react";
import RegisterApp from "./RegisterApp"; 

function App() {
  return (
    <div>
      <RegisterApp />  
    </div>
  );
}

export default App;
