import React from 'react';
import ContextApi from './ContextApi';
import Ref from './Ref';
import Track from './Track';

function App() {
  return (
    <div>
      <ContextApi />
      <Ref />
      <Track/>
    </div>
  );
}

export default App;