import React from 'react'
import Post from './Post'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'

const client = new QueryClient()

function App() {
  return (
    <QueryClientProvider client={client}>
      <div>
        <Post />
      </div>
    </QueryClientProvider>
  )
}

export default App
