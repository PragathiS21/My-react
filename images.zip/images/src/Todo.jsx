import axios from 'axios';
import React, { useEffect, useState } from 'react';
import './Todo.css'; // Import CSS file

function Todo() {
  const [todos, setTodos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [limit, setLimit] = useState(10);

  useEffect(() => {
    setLoading(true);
    axios
      .get("https://jsonplaceholder.typicode.com/todos")
      .then((res) => {
        setTodos(res.data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err);
        setLoading(false);
      });
  }, []);

  const handleLoadMore = () => {
    setLimit((prevLimit) => prevLimit + 5);
  }

  if (error) return <p className="error">Error fetching todos: {error.message}</p>;
  if (loading) return <p className="loading">Loading...</p>;

  return (
    <div className="todo-container">
      <h3 className="title">📋 Todo List</h3>
      {todos.slice(0, limit).map((todo) => (
        <div key={todo.id} className={`todo-item ${todo.completed ? 'completed' : 'pending'}`}>
          <h4>{todo.title}</h4>
          <p>Status: {todo.completed ? "☑ Completed" : "❌ Pending"}</p>
        </div>
      ))}

      {limit < todos.length && (
        <button 
          style={{marginTop: '20px', padding: '10px 20px', cursor: 'pointer'}} 
          onClick={handleLoadMore}
        >
          Load More
        </button>
      )}
    </div>
  );
}

export default Todo;
