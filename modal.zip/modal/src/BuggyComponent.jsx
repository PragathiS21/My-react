import React from 'react'

function BuggyComponent() {
    const [count,setCount]=useState(0);
    if(count===3){
        throw new Error("Crashed UI!")
    }
  return (
    <div>
      <button onClick-{() =>}
    </div>
  )
}

export default BuggyComponent
