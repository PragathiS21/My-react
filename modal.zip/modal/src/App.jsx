import React,{useState} from 'react';
import Modal from "./Modal"

function App() {
  const [open,setOpen]=
  useState(false);//create state
  return (
    <div>
      <button onClick={()=>
        setOpen(true)
      } style={{backgroundColor:"pink",padding:"20px",fontSize:"20px"}}>Open Modal</button>
      {open && (<Modal>
         <div style={{backgroundColor:"lightblue",padding:"40px",fontSize:"40px"}}>
           This is the notification popup
           <button style={{backgroundColor:"red",fontSize:"40px"}}onClick={()=>setOpen(false)}>close</button>
         </div>
         {/* <button onClick={()=>setOpen(false)}>Close Popup X</button> */}
      </Modal>)}
      <h2>Hello this is a sample message</h2>
    </div>
  );
}

export default App