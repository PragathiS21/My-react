import React from 'react'//use both single and double quotes
import {createPortal} from "react-dom";//close and open are two properties
// if we got the black screen which is not the error there we dont call thats it
function Modal({children}) {//pasing the arguments
  return createPortal ( //model is the child component
    <div>
      {children} 
    </div>,
    document.getElementById("modal-root")
  );
}

export default Modal