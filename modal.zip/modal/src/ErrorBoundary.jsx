import React from 'react'
class ErrorBoundary extends React.Component{
    render(){
        return this.state.hasError ? <h3>Opps!</h3>
    }

    
}
