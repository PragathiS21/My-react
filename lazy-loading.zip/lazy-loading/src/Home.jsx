import React from "react";
function Home() {
  return <div>This is Home Page</div>;
}
export default Home;
