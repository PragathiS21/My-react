import React from 'react'

function About() {
  return (
    <div>
      This is About Page
    </div>
  )
}

export default About
