import React from 'react'

function PersonalInfo() {
  return (
    <div>
      This is Personal Info Page
    </div>
  )
}

export default PersonalInfo
