import React, { useState } from 'react';

function PhoneValidation() {
  const [phone, setPhone] = useState("");
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const value = e.target.value;
    if (/^\d*$/.test(value)) {
      setPhone(value);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (phone.length !== 10) {
      setError("Please enter a valid number");
    } else {
      setError("");
      alert(`Phone number submitted: ${phone}`);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>Enter your phone number:</label>
      <input
        type="text"
        value={phone}
        onChange={handleChange}
        maxLength="10"
        placeholder="Enter 10-digit number"
      />
      <button type="submit">Submit</button>
      {error && <p style={{ color: "red" }}>{error}</p>}
    </form>
  );
}

export default PhoneValidation;
