import React from 'react'
import HTMLForms from './HTMLForms'
import ControlledForm from './ControlledForm'
import TwoWayBinding from './TwoWayBinding'
import SimpleValidation from './SimpleValidation'
import PhoneValidation from './PhoneValidation'

function App() {
  return (
    <div>
      <HTMLForms form=" "/>
      <ControlledForm form=" "/>
      <TwoWayBinding form=" "/>
      <SimpleValidation form=""/>
      <PhoneValidation form=""/>
    </div>
  )
}

export default App
