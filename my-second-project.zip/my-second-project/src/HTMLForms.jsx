import React from 'react'

function HTMLForms() {
  return (
        <forms>
            <input type="email" id="user"/>
            <input type="password" id="user"/>
            <button>Submit</button>
        </forms>
      
    
  )
}

export default HTMLForms
