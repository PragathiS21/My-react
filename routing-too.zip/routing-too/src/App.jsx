import React from 'react';
import ProductedRoutes from './ProductedRoutes/ProductedRoutes'; 
import Login from './ProductedRoutes/Login';
import Dashboard from './ProductedRoutes/Dashboard';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './ProductedRoutes/Home';
import User from './DynamicRouting'; // keep as is

function App() {
  return (
    <div>
      <h1>React Protected Routes Example</h1>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/Home" element={<Home />} />
          <Route
            path="/dashboard"
            element={
              <ProductedRoutes>
                <Dashboard />
              </ProductedRoutes>
            }
          />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
