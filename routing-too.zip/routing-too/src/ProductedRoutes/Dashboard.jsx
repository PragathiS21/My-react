import React from 'react'

function Dashboard() {
  return (
    <div>This is Dashboard</div>
  )
}

export default Dashboard
