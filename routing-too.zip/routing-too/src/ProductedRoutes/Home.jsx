import React from 'react'
import { Link } from 'react-router-dom'

function Home() {
  return (
    <div>
      This is Home page
      <Link to='/login'>Login Page</Link>
      <Link to='/users/:Pragathi'>Pragathi</Link>
      </div>
  )
}

export default Home
