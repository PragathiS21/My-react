import React from 'react'

function Login() {
    const handleLogin=() =>{
        localStorage.setItem("auth","true");
        window.location.href="/dashboard";
    };
  return (
    <div>
      <h2>This is Login Page</h2>
      <button onClick={handleLogin}>Login</button>
    </div>
  )
}

export default Login;
